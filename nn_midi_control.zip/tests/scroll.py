from PySide2 import QtWidgets

class Window(QtWidgets.QWidget):
    def __init__(self, val):
        QtWidgets.QWidget.__init__(self)
        mygroupbox = QtWidgets.QGroupBox('this is my groupbox')
        myform = QtWidgets.QFormLayout()
        labellist = []
        combolist = []
        for i in range(val):
            labellist.append(QtWidgets.QLabel('mylabel'))
            combolist.append(QtWidgets.QComboBox())
            myform.addRow(labellist[i],combolist[i])
        mygroupbox.setLayout(myform)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidget(mygroupbox)
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(400)
        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(scroll)

if __name__ == '__main__':

    import sys
    app = QtWidgets.QApplication(sys.argv)
    window = Window(25)
    window.setGeometry(500, 300, 300, 400)
    window.show()
    sys.exit(app.exec_())