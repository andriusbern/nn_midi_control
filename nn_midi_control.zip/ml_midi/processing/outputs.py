

class Outputs(object):
    """
    Contains all the functions for sending outputs
    based on classification outcome
    """
    def __init__(self):
        pass

    def send_midi(self):
        pass