from ml_midi.interface import QtInterface, Window, App

if __name__ == "__main__":

    # interface = QtInterface()
    interface = Window()
    interface.main()
    