from .conv import ConvNet
from .naive import RetardedClassifier