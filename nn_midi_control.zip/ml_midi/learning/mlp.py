import tensorflow as tf
import numpy as np
from ml_midi.config import ConfigManager as config
from random import shuffle
# from data_handler import DataIO, Dataset
from ml_midi.processing import DataIO, Dataset
import time

class MLP(object):
    """
    Save net parameters in YAML files
    """
    def __init__(self, config, dataset):
        # self.dataset = Dataset('default')
        self.n_labels = 1
        self.dataset = dataset
        self.dims = dataset.samples.shape[1:]
        print(self.dims)
        self.n_categories = len(np.unique(dataset.data_labels))

        self.lr = 0.0001
        self.config = config
        self.graph = tf.Graph()
        self.setup()
        self.session = tf.Session(graph=self.graph)
        self.session.run(self.init)

    def setup(self):
        with self.graph.as_default():
            self._placeholders()
            self._build_net()
            self.loss = tf.reduce_mean(tf.square(self.output - self.label_ph))
            # self.loss = tf.reduce_mean(-tf.reduce_sum(self.output * tf.log(self.label_ph), reduction_indices=[1])) #Categorical cross-entropy
            # self.cce = tf.keras.losses.CategoricalCrossentropy()
            self.train_op = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
            self.init = tf.global_variables_initializer()

    def _placeholders(self):
        self.input_ph = tf.placeholder(tf.float32, shape=(None, self.dims[0], self.dims[1], 1,), name='input')
        self.label_ph = tf.placeholder(tf.float32, shape=(None, self.n_categories), name='labels')
        
    def _build_net(self):
        """
        Build the network based on the network config parameters
        """
        output = tf.layers.conv2d(
            inputs=self.input_ph,
            filters=self.config['filters'][0],
            strides=self.config['strides'][0],
            kernel_size=self.config['kernel_size'][0],
            activation=tf.nn.relu,
            name='c0')

        for i, layer in enumerate(self.config['filters'][1:]):
            output = tf.layers.conv2d(
                inputs=output,
                filters=layer,
                strides=self.config['strides'][i+1],
                kernel_size=self.config['kernel_size'][i+1],
                activation=tf.nn.relu,
                name='c{}'.format(i+1))

        # Fully connected layers
        output = tf.layers.flatten(output)
        for i, layer in enumerate(self.config['fc_layers']):
            output = tf.layers.dense(
                output,
                layer,
                activation=tf.nn.relu,
                name='fc{}'.format(i))

        output = tf.layers.dense(
            output,
            self.n_categories,
            activation=tf.nn.softmax,
            name='output')

        self.output = output
        # self.init = tf.global_variables_initializer()
        # self.session = tf.Session(graph=self.graph)
        # self.session.run(self.init)

    def set_dataset(self, dataset):
        self.dataset = dataset

    def train(self, size=32):
        """
        Train the net
        """
 
        # for epoch in self.config.epochs:
        data, labels = self.dataset.get_batch(size)
        print(labels)
        data = np.expand_dims(data, axis=3)
        # labels = np.array(tf.one_hot(labels, self.n_categories))
        feed_dict = {self.input_ph: data,
                     self.label_ph: labels}
        t0 = time.time()
        out, loss, _ = self.session.run([self.output, self.loss, self.train_op], feed_dict=feed_dict)
        # output = self.classify(data)
        output_labels = np.argmax(np.squeeze(out), axis=1)
        acc = np.sum(output_labels == np.argmax(labels, axis=1)) / len(labels)
        print(time.time() - t0)
        # print('Epoch: {}/{}, loss: {}...'.format(epoch+1, self.config.epochs, loss))
        return loss, acc

    def validate(self):
        """
        Validate the current model on the test set
        """
        data, labels = self.dataset.test_x, self.dataset.test_y
        nl = len(self.dataset.labels)
        confmat = np.zeros([nl, nl])
        data = np.expand_dims(data, axis=3)
        output = self.classify(data)
        output_labels = np.argmax(output, axis=1)
        misclassified = output_labels == labels
        print(output_labels)
        print(labels)
        n_misclassified = np.sum(misclassified)
        print('Test set: correct classifications {}/{}'.format(n_misclassified, len(labels)))
        percent = n_misclassified/len(labels)
        for l, o in zip(labels, output_labels):
            confmat[l,o] += 0 if l==o else 1
            

        return percent, confmat

    def classify(self, x):
        """
        Forward pass through the net
        """
        feed_dict = {self.input_ph: x} #, self.output_ph: np.random.randint(0, 4, [1,4])
        out = self.session.run(self.output, feed_dict=feed_dict)
        return np.squeeze(out)

    def test(self, s, e):
        
        data = self.dataset.samples[s:e, :, :]
        data = np.expand_dims(data, axis=3)
        # data = data[:, np.newaxis]
        feed_dict = {self.input_ph: data}
        out = self.session.run(self.output, feed_dict=feed_dict)
        categories = np.argmax(out, axis=1)

        return np.squeeze(out), categories

    def save(self):
        pass

    def load(self):
        pass

    


