# Todo:

List:

1. All variables in the config file
2. Fix spectrogram rotation and cutoff

Threading:
    What can be put into threads?
    Audio object could be in a separate thread